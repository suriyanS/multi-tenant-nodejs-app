# Sample Multitenant Application in Node.js

https://blog.lftechnology.com/designing-a-secure-and-scalable-multi-tenant-application-on-node-js-15ae13dda778

Hey there, check out the blog post for more information.
